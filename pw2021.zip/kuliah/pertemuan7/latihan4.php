<?php
/* 
    Andrie Firmansyah
    203040173
    https://github.com/Andriefir/pw2021_203040173
    Pertemuan 7 - 26 Februari 2021 
    Materi Minggu ini mempelajari mengenai GET & POST
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>Selamat Datang, <?= $_POST["nama"] ?>!</h1>
</body>
</html>