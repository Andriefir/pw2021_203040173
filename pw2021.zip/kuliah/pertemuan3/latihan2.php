<?php
/*
Andrie Firmansyah
203040173
https://github.com/Andriefir/pw2021_203040173
Pertemuan 3 - 19 Februari 2021
Mempelajari tentang Pengulangan dan Pengkondisian dalam PHP
*/
?>
<?php 
// Pengkondisian / Percabangan
/*
if else
if else if else
ternary
switch
*/


$x = 2;
if( $x < 20 ) {
    echo "Benar";
} else if( $x == 20 ) {
    echo "Bingo!"; 
} else {
    echo "Salah";
}
?>