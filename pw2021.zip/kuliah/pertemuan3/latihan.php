<?php
/*
Andrie Firmansyah
203040173
https://github.com/Andriefir/pw2021_203040173
Pertemuan 3 - 19 Februari 2021
Mempelajari tentang Pengulangan dan Pengkondisian dalam PHP
*/ 
?>
<?php
// Pengulangan
/* 
for
while
do.. while
foreach : pengulangan khusus array
*/

// for( $i = 0; $i < 5; $i++ ) {
//     echo "Hello World <br>";
// }

// $i = 0;
// while( $i < 5 ) {
//     echo "Hello World <br>";
// $i++;
// }

// $i = 10;
// do {
//     echo "Hello World <br>";
// $i++;
// } while( $i < 5 )
?>