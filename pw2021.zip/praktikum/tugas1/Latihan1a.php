<?php 
/* 
  Mochammad Andrie Firmansyah
  203040173
  Jumat 13.00
  Latihan1a
  https://github.com/Andriefir/pw2021_203040173
*/
?>
<?php 
for( $i = 1; $i <= 3; $i++ ) {
	for( $j = 1; $j <= 3; $j++ ) {
  echo "Ini perulangan ke ($i,$j) <br>";
}
} 
?>